"""
Script to run network simulation for 1000ms for p={0,0.1,0.2,0.3,0.4,0.5} 
"""

from IzNetwork import IzNetwork
from Plot import *
import numpy as np

for i in range(6):
  # Rewiring probability p
  p = i / 10.0
  runtime = 1000
    
  IN = IzNetwork(p, runtime)
  IN.run()
  
  firings = IN.firings
  firingRates = [np.zeros(8) for count in range(runtime)]

  # Generate plots for questions a, b, c
  genA(IN.cm, p)
  firingRates = genB(runtime, firings, firingRates, p)
  genC(runtime, firingRates, p)
