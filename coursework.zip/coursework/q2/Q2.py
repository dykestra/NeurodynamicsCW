"""
Script to run 60s simulation N times and generate plot of rewiring probability against multi-information
"""

from jpype import *
import os
import numpy.random as rn
import sys
sys.path.append('../q1')
from IzNetwork import IzNetwork
from Plot import *

path = os.getcwd() + "/infodynamics.jar"
startJVM(getDefaultJVMPath(), "-Djava.class.path=" + path)

N  = 20
xs = []
ys = []

# run simulation N times
for i in range(N):
  print "Creating network {}".format(i)

  p =  rn.random()
  runtime = 60000
  
  IN = IzNetwork(p, runtime)
  IN.run()

  xs.append(p)
  ys.append(analyseFirings(IN.firings))

shutdownJVM()

# generate multi-information plot
genPlot(xs, ys)
