"""
Calculate multi-information from firing data
"""

from jpype import *
import numpy as np

# "data" is a list indexed by timestep, at each timestep we have the list of module firing rates: [[r1,...,r8],...,[r1,...,r8]] 

def MICalc(data):
    classKraskov2 = JPackage("infodynamics.measures.continuous.kraskov").MultiInfoCalculatorKraskov2
    kraskov = classKraskov2()

    kraskov.initialise(8)
    
    # Add observations
    kraskov.startAddObservations()
    
    javaArray = JArray(JDouble, 2)(data)
    kraskov.addObservations(javaArray)
        
    kraskov.finaliseAddObservations()
    
    # Calculate the multi-infrmation
    information = kraskov.computeAverageLocalOfObservations()

    # Conversion to bits
    return (information * np.log2(np.e))
